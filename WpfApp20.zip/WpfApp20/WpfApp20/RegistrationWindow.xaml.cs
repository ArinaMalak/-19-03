﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary1;

namespace WpfApp20
{
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void txtRegLogin_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Здесь можно разместить логику обработки изменения текста в поле логина
        }

        private void btnCreateAccount_Click_1(object sender, RoutedEventArgs e)
        {
            string login = txtRegLogin.Text;
            string password = pbRegPassword.Password;
            string confirmPassword = pbConfirmPassword.Password;

            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают.");
                return;
            }

            // Настройка строки подключения
            const string connectionString = "Data Source=303COMP-003\\SQLEXPRESS;Initial Catalog=practika;Integrated Security=True;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open(); // Открыть соединение

                    // SQL-запрос для вставки нового пользователя
                    string query = "INSERT INTO Users (Login, Password, Role) VALUES (@login, @password, @role)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Передача параметров в запрос
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@password", password); // Лучше использовать хеширование пароля!
                        cmd.Parameters.AddWithValue("@role", "Client");

                        int rowsAffected = cmd.ExecuteNonQuery(); // Выполнить команду

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Аккаунт успешно создан!");
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("Произошла ошибка при создании аккаунта.");
                        }
                    } // SqlCommand автоматически закрывается
                } // SqlConnection автоматически закрывается
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}