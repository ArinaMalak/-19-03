﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary1
{
    public class UserModel
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string Role { get; set; } // Client или Administrator
    }
}
