﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public static class AuthenticationService
    {
        private static List<UserModel> users = new List<UserModel>();

        static AuthenticationService()
        {
            // Инициализация тестовых пользователей
            users.Add(new UserModel { Login = "client", Password = "12345", Role = "Client" });
            users.Add(new UserModel { Login = "admin", Password = "54321", Role = "Administrator" });
        }

        public static bool Authenticate(string login, string password)
        {
            var user = users.FirstOrDefault(u => u.Login == login && u.Password == password);
            return user != null;
        }

        public static void Register(UserModel user)
        {
            users.Add(user);
        }

        public static string GetUserRole(string login)
        {
            var user = users.FirstOrDefault(u => u.Login == login);
            return user?.Role;
        }
    }
}
